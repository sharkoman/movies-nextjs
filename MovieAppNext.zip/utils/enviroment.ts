export const BackURI = 'https://movies-strapi-cms.herokuapp.com';
