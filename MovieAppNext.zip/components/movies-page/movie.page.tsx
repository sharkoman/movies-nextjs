import React from 'react'

const MoviePage: React.FC = () => {
	return (
		<>
			<h2>Movie Page</h2>	
		</>
	)
}

export default MoviePage;
